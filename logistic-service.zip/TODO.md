# TODO: Complete Logistics Microservice Implementation

## High Priority (Must Implement)
- [x] Replace mock contacts service with real HTTP calls to apis.gestoru.com/contacts/v1/list
- [x] Replace mock trazability service with real HTTP calls to apis.gestoru.com/base-event/create
- [x] Replace mock storage service with real file upload API
- [x] Fix hardcoded states in service (use proper enum values)
- [x] Add contact validation in create/update operations
- [x] Implement PDF generation with Puppeteer and Code 128 barcodes
- [x] Integrate Twilio for SMS/WhatsApp notifications
- [x] Add checkStartedAt timestamp when starting verification
- [x] Fix printGuide and sendNotification integrations
- [x] Fix files upload/get endpoints to use real storage service
- [x] Fix printing controller to pass tenantId parameter
- [x] Add recipient field to notify DTO
- [ ] Add Prisma seeds for demo data (1 tracking, 1 picking)
- [ ] Add comprehensive validations (required fields, business rules)
- [ ] Ensure socket events match specification exactly
- [ ] Implement proper state transitions per HU requirements

## Medium Priority
- [ ] Add unit tests for services
- [ ] Add integration tests for endpoints
- [ ] Complete OpenAPI documentation with examples
- [ ] Add structured JSON logging
- [ ] Configure Docker with database volumes
- [ ] Add health checks and metrics

## Low Priority (Optional)
- [ ] Add email notifications
- [ ] Advanced error handling with circuit breakers
- [ ] Performance optimizations
