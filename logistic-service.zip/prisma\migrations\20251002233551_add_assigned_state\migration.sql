-- AlterEnum
ALTER TYPE "LogisticState" ADD VALUE 'ASSIGNED';
