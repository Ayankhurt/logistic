import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';

// Feature modules
import { LogisticModule } from './logistic/logistic.module';
import { PrintingModule } from './printing/printing.module';
import { KanbanModule } from './kanban/kanban.module';
import { NotifyModule } from './notify/notify.module';
import { SocketsModule } from './sockets/sockets.module';
import { AuditModule } from './audit/audit.module';
import { CheckModule } from './check/check.module';
import { FilesModule } from './files/files.module';
import { ContactsModule } from './integrations/contacts/contacts.module';
import { StorageModule } from './integrations/storage/storage.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    LogisticModule,
    PrintingModule,
    KanbanModule,
    NotifyModule,
    FilesModule,
    SocketsModule,
    AuditModule,
    CheckModule,
    ContactsModule,
    StorageModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
