import { Controller, Get, UseGuards, Req } from '@nestjs/common';
import { AuthGuard } from './auth.guard';

@Controller('example')
export class ExampleController {
  @Get('protected')
  @UseGuards(AuthGuard)
  getProtectedResource(@Req() req: { user?: unknown }) {
    return {
      message: 'This is protected',
      user: req.user,
    };
  }
}
