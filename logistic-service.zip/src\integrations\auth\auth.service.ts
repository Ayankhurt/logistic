import { Injectable } from '@nestjs/common';

@Injectable()
export class AuthService {
  // Example: verify token
  verifyToken(token: string): boolean {
    // TODO: integrate with Auth service
    return !!token;
  }
}
