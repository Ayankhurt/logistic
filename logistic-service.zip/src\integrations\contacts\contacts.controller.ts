import { Controller, Get, Param, Query } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { ContactsService, Contact } from './contacts.service';

@ApiTags('Contacts')
@Controller('contacts')
export class ContactsController {
  constructor(private readonly contactsService: ContactsService) {}

  @Get()
  async listContacts(@Query('tenantId') tenantId: string) {
    return await this.contactsService.listContacts(tenantId);
  }

  @Get('validate/:id')
  async validateContact(
    @Param('id') id: string,
    @Query('tenantId') tenantId: string,
  ) {
    const valid = await this.contactsService.validateContact(id, tenantId);
    return { valid };
  }
}
