import { Injectable, Logger, HttpException } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

export interface Contact {
  id: string;
  name: string;
  email?: string;
}

@Injectable()
export class ContactsService {
  private readonly logger = new Logger(ContactsService.name);
  private readonly baseUrl = 'https://apis.gestoru.com';

  constructor(private readonly httpService: HttpService) {}

  /**
   * Fetch contacts from Contacts Service
   * @param tenantId Tenant ID
   */
  async listContacts(tenantId: string): Promise<Contact[]> {
    try {
      const url = `${this.baseUrl}/contacts/v1/list`;
      const response = await firstValueFrom(
        this.httpService.get(url, {
          headers: {
            Authorization: `Bearer ${process.env.AUTH_TOKEN}`,
            'tenant-id': tenantId,
          },
        }),
      );

      const contacts = response.data as Contact[];
      this.logger.log(
        `Fetched ${contacts.length} contacts for tenant ${tenantId}`,
      );
      return contacts;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      this.logger.error(`Error fetching contacts: ${message}`);
      throw new HttpException('Failed to fetch contacts', 500);
    }
  }

  /**
   * Validate if a contact exists
   * @param contactId Contact ID
   * @param tenantId Tenant ID
   */
  async validateContact(contactId: string, tenantId: string): Promise<boolean> {
    try {
      const contacts = await this.listContacts(tenantId);
      const exists = contacts.some((contact) => contact.id === contactId);
      this.logger.log(`Contact ${contactId} validation: ${exists}`);
      return exists;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      this.logger.error(`Error validating contact: ${message}`);
      return false;
    }
  }
}
