import { Injectable, Logger, HttpException } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class TrazabilityService {
  private readonly logger = new Logger(TrazabilityService.name);
  private readonly baseUrl = 'https://apis.gestoru.com';

  constructor(private readonly httpService: HttpService) {}

  async createEvent(payload: Record<string, unknown>): Promise<{
    status: string;
    payload: Record<string, unknown>;
  }> {
    try {
      const url = `${this.baseUrl}/base-event/create`;
      const response = await firstValueFrom(
        this.httpService.post<Record<string, unknown>>(url, payload, {
          headers: {
            Authorization: `Bearer ${process.env.AUTH_TOKEN}`,
            'Content-Type': 'application/json',
          },
        }),
      );

      this.logger.log(`Trazability event created: ${JSON.stringify(payload)}`);
      return { status: 'success', payload: response.data };
    } catch (error) {
      this.logger.error(
        `Error creating trazability event: ${error instanceof Error ? error.message : 'Unknown error'}`,
      );
      throw new HttpException('Failed to create trazability event', 500);
    }
  }
}
