// src/logistic/logistic.controller.ts
import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  Query,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { LogisticService } from './logistic.service';
import { LogisticRecord } from './interfaces/logistic.interface';
import { CreateLogisticRecordDto } from './dto/create-logistic-record.dto';
import { UpdateLogisticRecordDto } from './dto/update-logistic-record.dto';
import { ChangeStateDto } from './dto/change-state.dto';
import { QueryLogisticRecordsDto } from './dto/query-logistic-records.dto';
import { AssignMessengerDto } from './dto/assign-messenger.dto';
import { CheckItemsDto } from './dto/check-items.dto';
import { FinalizeCheckDto } from './dto/finalize-check.dto';
import { DuplicateDto } from './dto/duplicate.dto';
import { SplitLogisticRecordDto } from './dto/split-records.dto';
import { UpdateLabelsDto } from './dto/update-labels.dto';
import { DemoDto } from './dto/demo.dto';
import { PrintDto } from './dto/print.dto';
import { NotifyDto } from './dto/notify.dto';

@ApiTags('Logistic Records')
@Controller('api/v1/logistic/records')
export class LogisticController {
  constructor(private readonly logisticService: LogisticService) {}

  @Get()
  async list(
    @Query() query: QueryLogisticRecordsDto,
  ): Promise<{ success: boolean; data: LogisticRecord[] }> {
    const records = await this.logisticService.listRecords(query);
    return { success: true, data: records };
  }

  @Post()
  async create(@Body() dto: CreateLogisticRecordDto): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.createRecord(dto);
    return { success: true, data: record };
  }

  @Get(':id')
  async get(
    @Param('id') id: string,
    @Query('tenantId') tenantId: string,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.getRecord(id, tenantId);
    return { success: true, data: record };
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateLogisticRecordDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.updateRecord(id, dto);
    return { success: true, data: record };
  }

  @Patch(':id/state')
  async changeState(
    @Param('id') id: string,
    @Body() dto: ChangeStateDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.changeState(id, dto);
    return { success: true, data: record };
  }

  @Patch(':id/messenger')
  async assignMessenger(
    @Param('id') id: string,
    @Body() dto: AssignMessengerDto & { userId: string },
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.assignMessenger(
      id,
      dto.messengerId,
      dto.userId,
    );
    return { success: true, data: record };
  }

  @Patch(':id/check/verify')
  async verifyItems(
    @Param('id') id: string,
    @Body() dto: CheckItemsDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.checkItems(id, dto);
    return { success: true, data: record };
  }

  @Patch(':id/check/finalize')
  async finalizeCheck(
    @Param('id') id: string,
    @Body() dto: FinalizeCheckDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.finalizeCheck(id, dto);
    return { success: true, data: record };
  }

  @Post(':id/duplicate')
  async duplicate(
    @Param('id') id: string,
    @Body() dto: DuplicateDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.duplicateRecord(
      id,
      dto.copyExtraFields || false,
      dto.userId,
    );
    return { success: true, data: record };
  }

  @Post(':id/split')
  async split(
    @Param('id') id: string,
    @Body() dto: SplitLogisticRecordDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.splitRecord(id, dto);
    return { success: true, data: record };
  }

  @Patch(':id/labels')
  async updateLabels(
    @Param('id') id: string,
    @Body() dto: UpdateLabelsDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.updateRecord(id, {
      labels: dto.labels,
      userId: dto.userId,
    });
    return { success: true, data: record };
  }

  @Post(':id/print')
  async printGuide(
    @Param('id') id: string,
    @Body() dto: PrintDto,
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.printGuide(id, dto.format, dto.userId);
    return { success: true, data: record };
  }

  @Post(':id/notify')
  async sendNotification(
    @Param('id') id: string,
    @Body() dto: NotifyDto & { userId: string },
  ): Promise<{ success: boolean; data: LogisticRecord }> {
    const record = await this.logisticService.sendNotification(
      id,
      dto.channels[0], // For simplicity, use first channel
      dto.recipient,
      dto.userId,
    );
    return { success: true, data: record };
  }

  @Post('demo')
  demo(@Body() dto: DemoDto): { success: boolean; data: { message: string } } {
    return { success: true, data: { message: `Demo received: ${dto.message}` } };
  }

  @Delete(':id')
  async deleteRecord(
    @Param('id') id: string,
    @Body('userId') userId: string,
  ): Promise<{ success: boolean; message: string }> {
    await this.logisticService.deleteRecord(id, userId);
    return { success: true, message: 'Record deleted successfully' };
  }
}
