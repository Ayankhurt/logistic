// src/logistic/logistic.service.ts
import {
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { LogisticRecord } from './interfaces/logistic.interface';
import { SocketsService } from '../sockets/sockets.gateway';
import { CreateLogisticRecordDto } from './dto/create-logistic-record.dto';
import { UpdateLogisticRecordDto } from './dto/update-logistic-record.dto';
import { ChangeStateDto } from './dto/change-state.dto';
import { QueryLogisticRecordsDto } from './dto/query-logistic-records.dto';
import { PrismaService } from '../prisma/prisma.service';
import { CheckItemsDto } from './dto/check-items.dto';
import { FinalizeCheckDto } from './dto/finalize-check.dto';
import { SplitLogisticRecordDto } from './dto/split-records.dto';
import { LogisticState } from '../common/state/logistic-state.enum';
import { ContactsService } from '../integrations/contacts/contacts.service';
import { PrintingService } from '../printing/printing.service';
import { NotifyService } from '../notify/notify.service';

@Injectable()
export class LogisticService {
  private readonly logger = new Logger(LogisticService.name);
  constructor(
    private readonly socketsService: SocketsService,
    private readonly prisma: PrismaService,
    private readonly contactsService: ContactsService,
    private readonly printingService: PrintingService,
    private readonly notifyService: NotifyService,
  ) {}

  // --- CREATE RECORD ---
  async createRecord(dto: CreateLogisticRecordDto): Promise<LogisticRecord> {
    try {
      // Validate sender and recipient contacts
      const senderValid = await this.contactsService.validateContact(dto.senderContactId, dto.tenantId);
      if (!senderValid) {
        throw new BadRequestException(`Invalid sender contact ID: ${dto.senderContactId}`);
      }
      const recipientValid = await this.contactsService.validateContact(dto.recipientContactId, dto.tenantId);
      if (!recipientValid) {
        throw new BadRequestException(`Invalid recipient contact ID: ${dto.recipientContactId}`);
      }

      const guideNumber = `G-${Date.now()}`;
      const record = await this.prisma.logisticRecord.create({
        data: {
          id: randomUUID(),
          tenantId: dto.tenantId,
          type: dto.type,
          guideNumber,
          senderContactId: dto.senderContactId,
          recipientContactId: dto.recipientContactId,
          carrierId: dto.carrierId,
          labels: (dto.labels ?? []).join(','),
          extra: dto.extra,
          createdBy: dto.userId,
          items: {
            create: dto.items?.map((i) => ({
              id: randomUUID(),
              originItemId: i.originItemId,
              sku: i.sku,
              name: i.name,
              qtyExpected: i.qtyExpected,
            })),
          },
        },
        include: {
          items: true,
          audit: true,
        },
      });

      // Emit socket event
      this.socketsService.emitToTenant(
        dto.tenantId,
        'logistic.created',
        record,
      );

      return this.mapDbRecordToDomain(record);
    } catch (error) {
      const err = error as Error;
      this.logger.error(`Error creating record: ${err.message}`);
      throw err;
    }
  }

  // --- GET RECORD ---
  async getRecord(id: string, tenantId: string): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true, audit: true, children: true },
    });
    if (!record) throw new NotFoundException('Record not found');
    if (record.tenantId !== tenantId)
      throw new BadRequestException('Tenant mismatch');
    return this.mapDbRecordToDomain(record);
  }

  // --- UPDATE RECORD ---
  async updateRecord(
    id: string,
    dto: UpdateLogisticRecordDto,
  ): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.update({
      where: { id },
      data: {
        labels: dto.labels?.join(','),
        extra: dto.extra as any,
        carrierId: dto.carrierId,
        updatedBy: dto.userId,
      },
      include: { items: true, audit: true, children: true },
    });

    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.updated',
      record,
    );
    return this.mapDbRecordToDomain(record);
  }

  // --- CHANGE STATE ---
  async changeState(id: string, dto: ChangeStateDto): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.update({
      where: { id },
      data: { state: dto.state as any },
      include: { items: true, audit: true, children: true },
    });
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.state.changed',
      record,
    );
    return this.mapDbRecordToDomain(record);
  }

  // --- LIST RECORDS ---
  async listRecords(query: QueryLogisticRecordsDto): Promise<LogisticRecord[]> {
    const where: any = {};

    if (query.tenantId) where.tenantId = query.tenantId;
    if (query.type) where.type = query.type;
    if (query.state) where.state = query.state;
    if (query.messengerId) where.messengerId = query.messengerId;
    if (query.labels && query.labels.length > 0) {
      where.labels = {
        contains: query.labels.join(','),
      };
    }

    const records = await this.prisma.logisticRecord.findMany({
      where,
      include: { items: true, audit: true, children: true },
      orderBy: { createdAt: 'desc' },
    });

    return records.map((record) => this.mapDbRecordToDomain(record));
  }

  // --- CHECK ITEMS ---
  async checkItems(id: string, dto: CheckItemsDto): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!record) throw new NotFoundException('Record not found');

    // Set checkStartedAt if not already set
    const checkStartedAt = record.checkStartedAt || new Date();

    // Update record with checkStartedAt if needed
    if (!record.checkStartedAt) {
      await this.prisma.logisticRecord.update({
        where: { id },
        data: { checkStartedAt },
      });
    }

    // Update each item with verified quantity
    for (const checkItem of dto.items) {
      await this.prisma.logisticItem.update({
        where: { id: checkItem.id },
        data: {
          qtyVerified: checkItem.qtyVerified,
          selected: checkItem.selected,
        },
      });
    }

    // Get updated record
    const updatedRecord = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true, audit: true, children: true },
    });

    // Create audit entry
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: record.tenantId,
        recordId: id,
        action: 'CHECK_VERIFIED',
        payload: JSON.stringify(dto.items),
        createdBy: dto.userId,
      },
    });

    // Emit socket event
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.items.checked',
      updatedRecord,
    );

    return this.mapDbRecordToDomain(updatedRecord);
  }

  // --- FINALIZE CHECK ---
  async finalizeCheck(
    id: string,
    dto: FinalizeCheckDto,
  ): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.update({
      where: { id },
      data: {
        checkFinalizedAt: new Date(),
        checkFinalizedBy: dto.userId,
        state: LogisticState.CHECK_FINALIZED as any,
      },
      include: { items: true, audit: true, children: true },
    });

    // Create audit entry
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: record.tenantId,
        recordId: id,
        action: 'CHECK_FINALIZED',
        createdBy: dto.userId,
      },
    });

    // Emit socket event
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.check.finalized',
      record,
    );

    return this.mapDbRecordToDomain(record);
  }

  // --- ASSIGN MESSENGER ---
  async assignMessenger(
    id: string,
    messengerId: string,
    userId: string,
  ): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.update({
      where: { id },
      data: {
        messengerId,
        state: LogisticState.ASSIGNED as any,
        updatedBy: userId,
      },
      include: { items: true, audit: true, children: true },
    });

    // Create audit entry
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: record.tenantId,
        recordId: id,
        action: 'MESSENGER_ASSIGNED',
        createdBy: userId,
        payload: JSON.stringify({ messengerId }),
      },
    });

    // Emit socket event
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.messenger.assigned',
      record,
    );

    return this.mapDbRecordToDomain(record);
  }

  // --- PRINT GUIDE ---
  async printGuide(
    id: string,
    format: string,
    userId: string,
  ): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true, audit: true, children: true },
    });

    if (!record) throw new NotFoundException('Record not found');

    // Generate PDF using PrintingService
    const fileUri = await this.printingService.generatePDF(id, record.tenantId);

    if (!fileUri) {
      throw new BadRequestException('Failed to generate print file');
    }

    // Update record with file URI
    const updatedRecord = await this.prisma.logisticRecord.update({
      where: { id },
      data: {
        fileUri,
        updatedBy: userId,
      },
      include: { items: true, audit: true, children: true },
    });

    // Create audit entry
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: record.tenantId,
        recordId: id,
        action: 'PRINTED',
        createdBy: userId,
        payload: JSON.stringify({ format }),
      },
    });

    // Emit socket event
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.guide.printed',
      updatedRecord,
    );

    return this.mapDbRecordToDomain(updatedRecord);
  }

  // --- SEND NOTIFICATION ---
  async sendNotification(
    id: string,
    channel: string,
    recipient: string,
    userId: string,
  ): Promise<LogisticRecord> {
    const record = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true, audit: true, children: true },
    });

    if (!record) throw new NotFoundException('Record not found');

    // Send notification using NotifyService
    if (channel.toLowerCase() === 'sms') {
      await this.notifyService.sendTrackingNotification(
        recipient,
        record.guideNumber,
        `https://tracking.example.com/${record.guideNumber}`,
      );
    } else if (channel.toLowerCase() === 'whatsapp') {
      await this.notifyService.sendWhatsAppTracking(
        recipient,
        record.guideNumber,
        `https://tracking.example.com/${record.guideNumber}`,
      );
    } else {
      throw new BadRequestException(`Unsupported notification channel: ${channel}`);
    }

    // Create audit entry
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: record.tenantId,
        recordId: id,
        action: 'NOTIFICATION_SENT',
        createdBy: userId,
        payload: JSON.stringify({ channel, recipient }),
      },
    });

    // Emit socket event
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.notification.sent',
      {
        ...record,
        notificationDetails: { channel, recipient },
      },
    );

    return this.mapDbRecordToDomain(record);
  }

  // --- DUPLICATE RECORD ---
  async duplicateRecord(
    id: string,
    copyExtraFields: boolean,
    userId: string,
  ): Promise<LogisticRecord> {
    const originalRecord = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!originalRecord) throw new NotFoundException('Record not found');

    // Create new record with data from original
    const newRecord = await this.prisma.logisticRecord.create({
      data: {
        id: randomUUID(),
        tenantId: originalRecord.tenantId,
        type: originalRecord.type,
        guideNumber: `G-${Date.now()}`,
        senderContactId: originalRecord.senderContactId,
        recipientContactId: originalRecord.recipientContactId,
        carrierId: originalRecord.carrierId,
        labels: originalRecord.labels,
        extra: copyExtraFields ? (originalRecord.extra as any) : null,
        createdBy: userId,
        items: {
          create: originalRecord.items.map((item) => ({
            id: randomUUID(),
            originItemId: item.originItemId,
            sku: item.sku,
            name: item.name,
            qtyExpected: item.qtyExpected,
          })),
        },
      },
      include: { items: true, audit: true },
    });

    // Create audit entry
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: originalRecord.tenantId,
        recordId: newRecord.id,
        action: 'DUPLICATED',
        createdBy: userId,
        payload: JSON.stringify({ originalRecordId: id }),
      },
    });

    // Emit socket event
    this.socketsService.emitToTenant(
      originalRecord.tenantId,
      'logistic.record.duplicated',
      newRecord,
    );

    return this.mapDbRecordToDomain(newRecord);
  }

  // --- SPLIT RECORD ---
  async splitRecord(
    id: string,
    dto: SplitLogisticRecordDto,
  ): Promise<LogisticRecord> {
    const originalRecord = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!originalRecord) throw new NotFoundException('Record not found');

    // Create new record as a child of the original
    const newRecord = await this.prisma.logisticRecord.create({
      data: {
        id: randomUUID(),
        tenantId: originalRecord.tenantId,
        type: originalRecord.type,
        guideNumber: `G-${Date.now()}-SPLIT`,
        senderContactId: originalRecord.senderContactId,
        recipientContactId: originalRecord.recipientContactId,
        carrierId: originalRecord.carrierId,
        labels: originalRecord.labels,
        extra: originalRecord.extra as any,
        parentRecordId: id,
        createdBy: dto.userId,
        items: {
          create: dto.items.map((splitItem) => {
            const originalItem = originalRecord.items.find(
              (item) => item.id === splitItem.originItemId,
            );

            if (!originalItem) {
              throw new BadRequestException(
                `Item with ID ${splitItem.originItemId} not found in original record`,
              );
            }

            if (splitItem.qtyToSplit > originalItem.qtyExpected) {
              throw new BadRequestException(
                `Cannot split more than available quantity for item ${splitItem.originItemId}`,
              );
            }

            return {
              id: randomUUID(),
              originItemId: originalItem.originItemId,
              sku: originalItem.sku,
              name: originalItem.name,
              qtyExpected: splitItem.qtyToSplit,
            };
          }),
        },
      },
      include: { items: true, audit: true },
    });

    // Update quantities in original record items
    for (const splitItem of dto.items) {
      const originalItem = originalRecord.items.find(
        (item) => item.id === splitItem.originItemId,
      );

      await this.prisma.logisticItem.update({
        where: { id: splitItem.originItemId },
        data: {
          qtyExpected: originalItem!.qtyExpected - splitItem.qtyToSplit,
        },
      });
    }

    // Create audit entries
    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: originalRecord.tenantId,
        recordId: id,
        action: 'SPLIT',
        createdBy: dto.userId,
        payload: JSON.stringify({ newRecordId: newRecord.id }),
      },
    });

    await this.prisma.auditLog.create({
      data: {
        id: randomUUID(),
        tenantId: originalRecord.tenantId,
        recordId: newRecord.id,
        action: 'CREATED_FROM_SPLIT',
        createdBy: dto.userId,
        payload: JSON.stringify({ parentRecordId: id }),
      },
    });

    // Emit socket events
    this.socketsService.emitToTenant(
      originalRecord.tenantId,
      'logistic.record.split',
      {
        originalRecord: await this.prisma.logisticRecord.findUnique({
          where: { id },
          include: { items: true, audit: true, children: true },
        }),
        newRecord,
      },
    );

    return this.mapDbRecordToDomain(newRecord);
  }

  // --- DELETE RECORD ---
  async deleteRecord(id: string, userId: string): Promise<void> {
    const record = await this.prisma.logisticRecord.findUnique({
      where: { id },
      include: { items: true },
    });

    if (!record) throw new NotFoundException('Record not found');

    // Delete associated items first
    await this.prisma.logisticItem.deleteMany({
      where: { recordId: id },
    });

    // Delete audit logs
    await this.prisma.auditLog.deleteMany({
      where: { recordId: id },
    });

    // Delete the record
    await this.prisma.logisticRecord.delete({
      where: { id },
    });

    // Create audit entry for deletion (optional, since record is deleted)
    // We can log this in a separate audit table if needed

    // Emit socket event
    this.socketsService.emitToTenant(
      record.tenantId,
      'logistic.record.deleted',
      { id, deletedBy: userId },
    );
  }

  private mapDbRecordToDomain(db: any): LogisticRecord {
    return {
      ...db,
      labels:
        typeof db.labels === 'string' && db.labels.length > 0
          ? db.labels.split(',')
          : [],
    } as LogisticRecord;
  }
}
