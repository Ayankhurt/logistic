import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  OnGatewayInit,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { Logger } from '@nestjs/common';

@WebSocketGateway({ namespace: '/logistics', cors: { origin: '*' } })
export class SocketsService implements OnGatewayInit {
  @WebSocketServer()
  server: Server;

  private readonly logger = new Logger(SocketsService.name);

  afterInit(): void {
    this.logger.log('Sockets Gateway Initialized');
  }

  handleConnection(client: Socket) {
    this.logger.log(`Client connected: ${client.id}`);
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`);
  }

  // --- Emit events to tenant room ---
  emitToTenant(tenantId: string, event: string, payload: any) {
    this.server.to(`tenant:${tenantId}`).emit(event, payload);
    this.logger.log(`Event emitted: ${event} to tenant:${tenantId}`);
  }

  // --- Emit events to messenger room ---
  emitToMessenger(messengerId: string, event: string, payload: any) {
    this.server.to(`messenger:${messengerId}`).emit(event, payload);
    this.logger.log(`Event emitted: ${event} to messenger:${messengerId}`);
  }

  // --- Optional: join rooms dynamically ---
  @SubscribeMessage('joinRoom')
  handleJoinRoom(client: Socket, room: string): void {
    void client.join(room);
    this.logger.log(`Client ${client.id} joined room ${room}`);
  }

  @SubscribeMessage('leaveRoom')
  handleLeaveRoom(client: Socket, room: string): void {
    void client.leave(room);
    this.logger.log(`Client ${client.id} left room ${room}`);
  }
}
